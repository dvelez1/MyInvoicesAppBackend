exports = {
    InvoicePaiymentsId:0,
    InvoiceId:"",
    Payment:"",
    TransactionDate:"",
    RemovedTransactionDate:"",
    RemovedTransaction:""
}