exports = {
    InvoiceId:0,
    StartDate:"",
    CustomerId:"",
    EndDate:"",
    TransactionActive:"",
    TotalAmount:"",
    PayedAmount:"",
    Void:"",
    Note:""
}