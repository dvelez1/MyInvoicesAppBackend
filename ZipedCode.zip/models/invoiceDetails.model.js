exports = {
    InvoiceDetailsId:0,
    InvoiceId:"",
    ProductId:"",
    Quantity:0,
    CatalogPrice:"",
    Price:"",
    RemovedTransaction:"",
    RemovedDate:""
}