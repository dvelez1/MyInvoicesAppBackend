exports = {
    CustomerId:0,
    Name:"",
    MiddleName:"",
    FirstName:"",
    LastName:"",
    Address1:"",
    Address2:"",
    City:"",
    State:"",
    ZipCode:"",
    StartDate:"",
    EndDate:"",
}