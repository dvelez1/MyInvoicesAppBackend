exports = {
    ProductId:0,
    Name:"",
    Price:"",
    StartDate:"",
    EndDate:""
}